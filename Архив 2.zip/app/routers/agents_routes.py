# app/routers/agents_routes.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import get_session
from app.models import Draft, DraftStatus, DraftType, SalesAvatar
from app.schemas import AgentRunPayload, AgentRunResponse
from agents.registry import AGENTS, run_agent

router = APIRouter(prefix="/agents", tags=["agents"])


def _avatar_to_str(avatar) -> str:
    if not avatar:
        return ""
    parts = []
    if avatar.positioning:
        parts.append(f"Positioning: {avatar.positioning}")
    if avatar.tone_guidelines:
        parts.append(f"Tone: {avatar.tone_guidelines}")
    if avatar.do_say:
        parts.append("Do say: " + ", ".join(avatar.do_say))
    if avatar.dont_say:
        parts.append("Don't say: " + ", ".join(avatar.dont_say))
    return "\n".join(parts)


@router.post("/{agent_name}/run", response_model=AgentRunResponse)
async def run_agent_endpoint(
    agent_name: str,
    body: AgentRunPayload,
    session: AsyncSession = Depends(get_session),
):
    if agent_name not in AGENTS:
        raise HTTPException(404, f"Unknown agent: {agent_name}")
    payload = body.payload or {}

    # Inject shared memory (Sales Avatar) when needed
    if agent_name in ("content_agent", "comment_agent", "outreach_sequencer", "qa_guard"):
        r = await session.execute(select(SalesAvatar).limit(1))
        avatar = r.scalar_one_or_none()
        if avatar and "sales_avatar" not in payload and "context" not in payload:
            payload.setdefault("sales_avatar", _avatar_to_str(avatar))
            payload.setdefault("context", _avatar_to_str(avatar))

    result = await run_agent(agent_name, payload)
    draft_id = None

    # Save as draft when content is produced
    if agent_name == "content_agent" and result.get("content"):
        c = result["content"]
        draft = Draft(
            type=DraftType.POST.value,
            content=c.get("draft", ""),
            source_agent=agent_name,
            meta={"cta": c.get("cta"), "final_question": c.get("final_question"), "draft_short": c.get("draft_short"), "visual_suggestion": c.get("visual_suggestion")},
            status=DraftStatus.DRAFT.value,
        )
        session.add(draft)
        await session.flush()
        draft_id = draft.id
    elif agent_name == "comment_agent" and result.get("comments"):
        comm = result["comments"]
        text = comm.get("medium") or comm.get("short") or comm.get("long") or ""
        draft = Draft(
            type=DraftType.COMMENT.value,
            content=text,
            source_agent=agent_name,
            meta={"short": comm.get("short"), "long": comm.get("long")},
            status=DraftStatus.DRAFT.value,
        )
        session.add(draft)
        await session.flush()
        draft_id = draft.id
    elif agent_name == "outreach_sequencer" and result.get("sequencer", {}).get("draft_message"):
        draft = Draft(
            type=DraftType.DM.value,
            content=result["sequencer"]["draft_message"],
            source_agent=agent_name,
            person_id=payload.get("person_id"),
            meta=result.get("sequencer"),
            status=DraftStatus.DRAFT.value,
        )
        session.add(draft)
        await session.flush()
        draft_id = draft.id

    return AgentRunResponse(agent_name=agent_name, result=result, draft_id=draft_id)
