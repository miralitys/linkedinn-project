# agents/comment_agent.py
from typing import Any

from agents.base import AgentBase
from agents.utils import extract_json


class CommentAgent(AgentBase):
    name = "comment_agent"

    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        post_text = payload.get("post_text", "")
        sales_avatar = payload.get("sales_avatar", "")
        goal = payload.get("goal", "прогрев")
        author = payload.get("author") or {}
        if author and author.get("full_name"):
            author_desc = (
                f"Автор (от чьего лица пиши комментарий): {author.get('full_name', '')}. "
                f"Роль: {author.get('role') or '—'}. "
                f"История/стиль: {author.get('history') or '—'}"
            )
        else:
            author_desc = "Автор не выбран — пиши в общем тоне Sales Avatar."

        system = self.get_system_prompt()
        user_tpl = self.get_user_prompt_template()
        user = user_tpl.format(
            post_text=post_text,
            sales_avatar=sales_avatar,
            goal=goal,
            author=author_desc,
        )
        response = await self._llm.chat(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            temperature=0.5,
            max_tokens=1024,
        )
        try:
            data = extract_json(response)
            return {"comments": data, "raw": response}
        except Exception:
            return {"comments": {}, "raw": response, "error": "Failed to parse JSON"}
