# agents/news_post_agent.py
"""Агент: авторский LinkedIn-пост на основе новости (профиль автора + продукты + цель)."""
from typing import Any

from agents.base import AgentBase


class NewsPostAgent(AgentBase):
    name = "news_post_agent"

    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        news_text = payload.get("news_text", "") or payload.get("post_text", "")
        sales_avatar = payload.get("sales_avatar", "")
        goal = payload.get("goal", "network")
        author = payload.get("author") or {}
        products_raw = payload.get("products") or []

        if author and (author.get("full_name") or author.get("history")):
            author_desc = (
                f"Имя: {author.get('full_name', '')}. "
                f"Роль: {author.get('role') or '—'}. "
                f"История/стиль: {author.get('history') or '—'}"
            )
        else:
            author_desc = "Автор не выбран — пиши в общем тоне, нейтрально."

        products_lines = []
        for i, p in enumerate(products_raw, 1):
            if isinstance(p, dict):
                name = p.get("name") or ""
                desc = p.get("description") or ""
                products_lines.append(f"{i}. {name}" + (f" — {desc}" if desc else ""))
            elif isinstance(p, str) and p.strip():
                products_lines.append(f"{i}. {p.strip()}")
        products_str = "\n".join(products_lines) if products_lines else "Продукты не загружены."

        goal_label = {
            "network": "network — без продукта, нетворк по теме новости",
            "native_ads": "native_ads — нативная интеграция продукта, если уместно",
            "full_ads": "full_ads — полная интеграция одного продукта по смыслу новости",
        }.get(goal, goal)

        system = self.get_system_prompt()
        user_tpl = self.get_user_prompt_template()
        user = user_tpl.format(
            news_text=news_text,
            sales_avatar=sales_avatar,
            goal=goal_label,
            author=author_desc,
            products=products_str,
        )
        response = await self._llm.chat(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            temperature=0.5,
            max_tokens=2048,
        )
        post_text = (response or "").strip()
        return {"post": post_text, "raw": response}
