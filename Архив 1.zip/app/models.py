# app/models.py
import json
from datetime import datetime
from enum import Enum as PyEnum
from typing import Any, Optional

from sqlalchemy import (
    Boolean,
    JSON,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import TypeDecorator


class JsonAsText(TypeDecorator):
    """Stores list/dict as JSON string for SQLite; returns list/dict on read."""
    impl = Text
    cache_ok = True

    def process_bind_param(self, value: Any, dialect: Any) -> Optional[str]:
        if value is None:
            return None
        if isinstance(value, (list, dict)):
            return json.dumps(value, ensure_ascii=False)
        return str(value)

    def process_result_value(self, value: Any, dialect: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, str):
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        return value


class Base(DeclarativeBase):
    pass


class PersonStatus(str, PyEnum):
    NEW = "New"
    CONNECTED = "Connected"
    ENGAGED = "Engaged"
    WARM = "Warm"
    DM_SENT = "DM_Sent"
    REPLIED = "Replied"
    CALL_BOOKED = "Call_Booked"
    WON = "Won"
    LOST = "Lost"


class TouchType(str, PyEnum):
    LIKE = "like"
    COMMENT = "comment"
    DM = "dm"
    POST = "post"
    OTHER = "other"


class TouchDirection(str, PyEnum):
    OUTBOUND = "outbound"
    INBOUND = "inbound"


class TouchChannel(str, PyEnum):
    LINKEDIN = "linkedin"
    OTHER = "other"


class DraftType(str, PyEnum):
    POST = "post"
    COMMENT = "comment"
    DM = "dm"


class DraftStatus(str, PyEnum):
    DRAFT = "draft"
    QA_PENDING = "qa_pending"
    APPROVED = "approved"
    REJECTED = "rejected"


# --------------- Core entities ---------------


class Company(Base):
    __tablename__ = "companies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(512), nullable=False)
    website_url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    linkedin_url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    industry: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    geo: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    size_range: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tech_stack: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # json or text
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    people: Mapped[list["Person"]] = relationship("Person", back_populates="company")


class Segment(Base):
    __tablename__ = "segments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    rules: Mapped[Optional[dict]] = mapped_column(JsonAsText, nullable=True)
    priority: Mapped[int] = mapped_column(Integer, default=0)
    red_flags: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    include_examples: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    exclude_examples: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    people: Mapped[list["Person"]] = relationship("Person", back_populates="segment")


class Person(Base):
    __tablename__ = "people"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), nullable=True)
    full_name: Mapped[str] = mapped_column(String(256), nullable=False)
    title: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    linkedin_url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    feed_url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    geo: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    segment_id: Mapped[Optional[int]] = mapped_column(ForeignKey("segments.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default=PersonStatus.NEW.value)
    priority: Mapped[int] = mapped_column(Integer, default=0)
    hook_points: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    red_flags: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_kol: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    last_touch_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    company: Mapped[Optional["Company"]] = relationship("Company", back_populates="people")
    segment: Mapped[Optional["Segment"]] = relationship("Segment", back_populates="people")
    touches: Mapped[list["Touch"]] = relationship("Touch", back_populates="person", order_by="Touch.created_at")
    posts: Mapped[list["ContactPost"]] = relationship("ContactPost", back_populates="person", order_by="ContactPost.posted_at")


class KOL(Base):
    __tablename__ = "kol"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    full_name: Mapped[str] = mapped_column(String(256), nullable=False)
    linkedin_url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    topic_tags: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    priority: Mapped[int] = mapped_column(Integer, default=0)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    last_seen_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class Touch(Base):
    __tablename__ = "touches"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id"), nullable=False)
    type: Mapped[str] = mapped_column(String(32), nullable=False)  # TouchType
    direction: Mapped[str] = mapped_column(String(16), nullable=False)  # TouchDirection
    channel: Mapped[str] = mapped_column(String(16), nullable=False)  # TouchChannel
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    person: Mapped["Person"] = relationship("Person", back_populates="touches")


class ContactPost(Base):
    """Пост контакта (LinkedIn и др.): привязка к person_id, данные вносятся вручную или из интеграции."""
    __tablename__ = "contact_posts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    post_url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    posted_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    likes_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    comments_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    views_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    tags: Mapped[Optional[list]] = mapped_column(JsonAsText, nullable=True)
    archived: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    person: Mapped["Person"] = relationship("Person", back_populates="posts")


class SalesAvatar(Base):
    __tablename__ = "sales_avatar"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    positioning: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tone_guidelines: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    do_say: Mapped[Optional[list]] = mapped_column(JsonAsText, nullable=True)
    dont_say: Mapped[Optional[list]] = mapped_column(JsonAsText, nullable=True)
    examples_good: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    examples_bad: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class Offer(Base):
    __tablename__ = "offers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    target_segment_id: Mapped[Optional[int]] = mapped_column(ForeignKey("segments.id"), nullable=True)
    promise: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    proof_points: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # json or text
    objections: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    cta_style: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class LeadMagnet(Base):
    __tablename__ = "lead_magnets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    format: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)  # pdf/doc/checklist/template
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    outline: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    variants: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class KnowledgeBase(Base):
    __tablename__ = "knowledge_base"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    value: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    tags: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)  # comma-separated
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Draft(Base):
    __tablename__ = "drafts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    type: Mapped[str] = mapped_column(String(32), nullable=False)  # DraftType
    content: Mapped[str] = mapped_column(Text, nullable=False)
    source_agent: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    person_id: Mapped[Optional[int]] = mapped_column(ForeignKey("people.id"), nullable=True)
    kol_id: Mapped[Optional[int]] = mapped_column(ForeignKey("kol.id"), nullable=True)
    meta: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)  # CTA, question, etc.
    qa_result: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    status: Mapped[str] = mapped_column(String(32), default=DraftStatus.DRAFT.value)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class LinkedInOAuth(Base):
    """Один подключённый аккаунт LinkedIn (OAuth + refresh token)."""
    __tablename__ = "linkedin_oauth"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    access_token: Mapped[str] = mapped_column(Text, nullable=False)
    refresh_token: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    refresh_token_expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    scope: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class LinkedInDailyMetric(Base):
    """Метрики постов из memberCreatorPostAnalytics (q=me, aggregation=DAILY)."""
    __tablename__ = "linkedin_daily_metrics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    metric_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    metric_type: Mapped[str] = mapped_column(String(32), nullable=False)
    count: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
