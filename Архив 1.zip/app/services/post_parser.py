# app/services/post_parser.py
"""
Парсинг поста по прямой ссылке: Playwright открывает URL, скриншот карточки поста → GPT Vision → JSON.
Требует: playwright, openai. Для доступа к постам LinkedIn нужна авторизация в браузере (см. user_data_dir).
"""
import base64
import json
import logging
import re
from datetime import datetime
from typing import Any, Optional

from app.config import settings

# Селекторы для карточки поста (LinkedIn и др.) — по порядху попытки
POST_CARD_SELECTORS = [
    "article",
    "[role='article']",
    ".feed-shared-update-v2",
    ".scaffold-finite-scroll__content > div",
    "main section",
    "main",
]

VISION_PROMPT = """По скриншоту карточки поста в соцсети (LinkedIn или другой) верни строго один JSON-объект без markdown и без пояснений.
Схема:
{
  "author_name": "имя автора поста (как на экране)",
  "author_profile_url": "URL профиля или null если не видно",
  "post_url": "URL этого поста или null",
  "published_at": "дата/время поста как на экране (например 2 дн. или 7 фев 2026)",
  "text": "полный текст поста",
  "media_present": true или false,
  "reactions_count": число или null,
  "comments_count": число или null,
  "reposts_count": число или null,
  "views_count": число или null
}
Если чего-то не видно — используй null. published_at оставь как на экране (относительное или точное)."""


async def _screenshot_post_card(url: str, user_data_dir: Optional[str] = None) -> tuple[Optional[bytes], Optional[str]]:
    """Открывает url в Chromium, снимает скриншот карточки поста (или страницы). Возвращает (PNG bytes, None) или (None, error_message)."""
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        return None, "Playwright не установлен. Выполните: pip install playwright && playwright install chromium"

    try:
        async with async_playwright() as p:
            if user_data_dir:
                context = await p.chromium.launch_persistent_context(
                    user_data_dir,
                    headless=True,
                    viewport={"width": 1200, "height": 900},
                    timeout=15000,
                )
                page = context.pages[0] if context.pages else await context.new_page()
            else:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context(
                    viewport={"width": 1200, "height": 900},
                    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                )
                page = await context.new_page()

            await page.goto(url, wait_until="domcontentloaded", timeout=15000)
            await page.wait_for_timeout(2000)

            screenshot_bytes = None
            for selector in POST_CARD_SELECTORS:
                try:
                    loc = page.locator(selector).first
                    if await loc.count() > 0:
                        screenshot_bytes = await loc.screenshot(type="png", timeout=5000)
                        break
                except Exception:
                    continue
            if not screenshot_bytes:
                screenshot_bytes = await page.screenshot(type="png")

            if user_data_dir:
                await context.close()
            else:
                await browser.close()
            return screenshot_bytes, None
    except Exception as e:
        logging.exception("post_parser screenshot failed: %s", e)
        return None, str(e)


def _parse_vision_json(raw: str) -> Optional[dict[str, Any]]:
    """Извлекает JSON из ответа модели (может быть обёрнут в ```json ... ```)."""
    raw = (raw or "").strip()
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
    if m:
        raw = m.group(1).strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


async def parse_post_from_url(
    url: str,
    *,
    user_data_dir: Optional[str] = None,
    openai_api_key: Optional[str] = None,
    openai_model: str = "gpt-4o-mini",
) -> dict[str, Any]:
    """
    Открывает url, снимает скриншот карточки поста, отправляет в GPT Vision, возвращает распознанный JSON.
    При ошибке возвращает {"error": "..."}.
    """
    screenshot_bytes, screenshot_error = await _screenshot_post_card(url, user_data_dir=user_data_dir)
    if not screenshot_bytes:
        return {"error": screenshot_error or "Не удалось сделать скриншот страницы."}

    b64 = base64.standard_b64encode(screenshot_bytes).decode("ascii")
    api_key = openai_api_key or settings.openai_api_key
    if not api_key:
        return {"error": "OPENAI_API_KEY не задан. Нужен для распознавания текста по скриншоту."}

    try:
        from openai import AsyncOpenAI
    except ImportError:
        return {"error": "Пакет openai не установлен."}

    client = AsyncOpenAI(api_key=api_key)
    content: list[Any] = [
        {"type": "text", "text": VISION_PROMPT},
        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
    ]
    resp = await client.chat.completions.create(
        model=openai_model,
        messages=[{"role": "user", "content": content}],
        max_tokens=1024,
    )
    raw = (resp.choices[0].message.content or "").strip() if resp.choices else ""
    parsed = _parse_vision_json(raw)
    if not parsed:
        return {"error": "Модель не вернула валидный JSON.", "raw": raw[:500]}

    parsed.setdefault("post_url", url)
    return parsed
